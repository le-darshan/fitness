<?php
/**
 * WPBakery Visual Composer row
 *
 * @package WPBakeryVisualComposer
 *
 */

class WPBakeryShortCode_VC_Row_Inner extends WPBakeryShortCode_VC_Row {
    protected $predefined_atts = array(
        'el_class' => '',
		'width' => '1/1',
		'image' => '',
		'el_position' => '',
		'paddingtop'  => '',
		'paddingbottom'  => '',
		'full_width'  => '',
		'img_link_target' => '',
		'color'=> '',

    );
    public function content( $atts, $content = null ) {
        $el_class = $width = $images = $img_link_target = $paddingtop = $paddingbottom = $full_width = $color = '';
        $output = '';
        extract(shortcode_atts(array(
            'el_class' => '',
			'width' => '1/2',
			'image' => $image,
            //'el_position' => '',
			'img_size'  => 'thumbnail',
			'img_link_target' => '_self',
			'paddingtop'  => '30',
			'paddingbottom'  => '30',
			'full_width'  => '',
			'color'=> '',
        ), $atts));
        $img = wpb_getImageBySize(array( 'attach_id' => preg_replace('/[^\d]/', '', $image), 'thumb_size' => $img_size ));
		$id=rand();
		
		$bg = ($img['p_img_large'][0]);
		//echo $color;
        wp_enqueue_style( 'js_composer_front' );
        wp_enqueue_script( 'wpb_composer_front_js' );
		$el_class .= ((isset($color) || isset($bg)) && ($color != '' || $bg != '')) ? ' is_background' : '';
        $output .= '<div class="wpb_row '.get_row_css_class().' '.$el_class.'" style="padding-top:'.$paddingtop.'px;padding-bottom:'.$paddingbottom.'px; " id="row-'.$id.'">';
		if($bg!=''){
			$output .= '<style type="text/css" scoped="scoped">
				#row-'.$id.'{background-image: url('.$bg.'); background-size:cover; background-attachment: fixed; background-position: 50% 0%; background-repeat: no-repeat no-repeat; position:relative}
			</style>';
			
		}
		if($color!=''){
			$output .= '<style type="text/css" scoped="scoped">
				#row-'.$id.'{background-color:'.$color.';}
			</style>';
		}
		
		
		if($full_width==1){
		$output .= '<style type="text/css" scoped="scoped">	
			#row-'.$id.' .container-pad{ padding-left:0; padding-right:0}
			body.boxed #body #row-'.$id.'.vc_row-fluid {padding-left: 0;padding-right: 0;}
		</style>';	
		}
		$output .= '<div class="container-pad">';
		//$output .='<img src="'.$bg.'"/>';
		//$output .= "\n\t\t\t".wpb_widget_title(array('title' => $title, 'extraclass' => 'wpb_singleimage_heading'));
       // $output .= "\n\t\t\t".$image_string;

        $output .= wpb_js_remove_wpautop($content);
		$output .= '</div>';
        $output .= '</div>'.$this->endBlockComment('row');
        return $output;
    }



    /* This returs block controls
   ---------------------------------------------------------- */
    public function getColumnControls($controls, $extended_css = '') {
        global $vc_row_layouts;
        $controls_start = '<div class="controls controls_row clearfix">';
        $controls_end = '</div>';

        $right_part_start = '';//'<div class="controls_right">';
        $right_part_end = '';//'</div>';

        //Create columns
        $controls_center_start = '<span class="vc_row_layouts">';
        $controls_layout = '';
        foreach($vc_row_layouts as $layout) {
            $controls_layout .= '<a class="set_columns '.$layout['icon_class'].'" data-cells="'.$layout['cells'].'" data-cells-mask="'.$layout['mask'].'" title="'.$layout['title'].'"></a> ';
        }
        $controls_layout .= '<br/><a class="set_columns custom_columns" data-cells="custom" data-cells-mask="custom" title="'.__('Custom layout', 'js_composer').'">'.__('Custom layout', 'js_composer').'</a> ';
        $controls_move = ' <a class="column_move" href="#" title="'.__('Drag row to reorder', 'js_composer').'"></a>';
        $controls_delete = '<a class="column_delete" href="#" title="'.__('Delete this row', 'js_composer').'"></a>';
        $controls_edit = ' <a class="column_edit" href="#" title="'.__('Edit this row', 'js_composer').'"></a>';
        $controls_clone = ' <a class="column_clone" href="#" title="'.__('Clone this row', 'js_composer').'"></a>';
        $controls_center_end = '</span>';

        $row_edit_clone_delete = '<span class="vc_row_edit_clone_delete">';
        $row_edit_clone_delete .= $controls_delete . $controls_clone . $controls_edit;
        $row_edit_clone_delete .= '</span>';

        //$column_controls_full =  $controls_start. $controls_move . $controls_center_start . $controls_layout . $controls_delete . $controls_clone . $controls_edit . $controls_center_end . $controls_end;
        $column_controls_full =  $controls_start. $controls_move . $controls_center_start . $controls_layout . $controls_center_end . $row_edit_clone_delete . $controls_end;

        return $column_controls_full;
    }

    public function contentAdmin($atts, $content = null) {
        $width = $el_class = '';
        extract(shortcode_atts($this->predefined_atts, $atts));

        $output = '';

        $column_controls = $this->getColumnControls($this->settings('controls'));

        for ( $i=0; $i < count($width); $i++ ) {
            $output .= '<div'.$this->customAdminBockParams().' data-element_type="'.$this->settings["base"].'" class="wpb_'.$this->settings['base'].' wpb_sortable">';
            $output .= str_replace("%column_size%", 1, $column_controls);
            $output .= '<div class="wpb_element_wrapper">';
            $output .= '<div class="vc_row-fluid wpb_row_container vc_container_for_children">';
            if($content=='' && !empty($this->settings["default_content_in_template"])) {
                $output .= do_shortcode( shortcode_unautop($this->settings["default_content_in_template"]) );
            } else {
                $output .= do_shortcode( shortcode_unautop($content) );

            }
            $output .= '</div>';
            if ( isset($this->settings['params']) ) {
                $inner = '';
                foreach ($this->settings['params'] as $param) {
                    $param_value = isset($$param['param_name']) ? $$param['param_name'] : '';
                    if ( is_array($param_value)) {
                        // Get first element from the array
                        reset($param_value);
                        $first_key = key($param_value);
                        $param_value = $param_value[$first_key];
                    }
                    $inner .= $this->singleParamHtmlHolder($param, $param_value);
                }
                $output .= $inner;
            }
            $output .= '</div>';
            $output .= '</div>';
        }

        return $output;
    }
    public function customAdminBockParams() {
        return '';
    }
}

