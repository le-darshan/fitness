// JavaScript Document
(function() {
    // Creates a new plugin class and a custom listbox
    tinymce.create('tinymce.plugins.shortcode_button', {
        createControl: function(n, cm) {
            switch (n) {                
                case 'shortcode_button':
                var c = cm.createSplitButton('shortcode_button', {
                    title : 'Button',
                    onclick : function() {
                    }
                });

                c.onRenderMenu.add(function(c, m) {
                    m.onShowMenu.add(function(c,m){
                        jQuery('#menu_'+c.id).height('auto').width('auto');
                        jQuery('#menu_'+c.id+'_co').height('auto').addClass('mceListBoxMenu'); 
                        var $menu = jQuery('#menu_'+c.id+'_co').find('tbody:first');
                        if($menu.data('added')) return;
                        $menu.append('');
                        $menu.append('<tr><td><div style="padding:10px 10px 10px">\
                        <label>Button Size<br />\
						<select name="size">\
							<option value="small">Small</option>\
							<option value="big">Big</option>\
						</select></label>\
						<label>Text Of Button<br />\
                        <input type="text" name="text" value="Button" /></label>\
						<label>Link Of Button<br />\
                        <input type="text" name="links" value="" /></label>\
						<label>Icon in font <a style="display:inline;text-decoration:underline !important;cursor:pointer;" href="http://fortawesome.github.io/Font-Awesome/icons/">Awesome</a><br />\
						<i style="font-size:10px;">EX: icon-mobile-phone</i><br/>\
                        <input type="text" name="icon" value="" /></label>\
						<div class="form-item"><label for="color">Text Color</label><input type="text" id="color" name="color" value="#" /></div><div id="picker"></div>\
						<div class="form-item"><label for="text_color_hover">Text color when hover</label><input type="text" name="text_color_hover" id="text_color_hover" value="#" /></div><div id="picker3"></div>\
						<div class="form-item"><label for="bgcolor">Background Color</label><input type="text" id="bgcolor" name="bgcolor" value="#" /></div><div id="picker2"></div>\
						<div class="form-item"><label for="bgcolor">Background Color Hover</label><input type="text" id="bg_color_hover" name="bg_color_hover" value="#" /></div><div id="picker4"></div>\
                        </div></td></tr>');
						  jQuery(document).ready(function() {
							jQuery('#demo').hide();
							jQuery('#picker').hide();
							jQuery('#color').click(function(){
								jQuery('#menu_content_content_shortcode_button_menu_tbl').css("width","207px");
								jQuery('#picker').farbtastic('#color').show();
								jQuery('#picker2').farbtastic('#bgcolor').hide();
								jQuery('#picker3').farbtastic('#text_color_hover').hide();
								jQuery('#picker4').farbtastic('#bg_color_hover').hide();
							});
							jQuery('#text_color_hover').click(function(){
								jQuery('#menu_content_content_shortcode_button_menu_tbl').css("width","207px");
								jQuery('#picker4').farbtastic('#bg_color_hover').hide();
								jQuery('#picker3').farbtastic('#text_color_hover').show();
								jQuery('#picker2').farbtastic('#bgcolor').hide();
								jQuery('#picker').farbtastic('#bgcolor').hide();
							});
							jQuery('#bgcolor').click(function(){
								jQuery('#menu_content_content_shortcode_button_menu_tbl').css("width","207px");
								jQuery('#picker4').farbtastic('#bg_color_hover').hide();
								jQuery('#picker3').farbtastic('#text_color_hover').hide();
								jQuery('#picker2').farbtastic('#bgcolor').show();
								jQuery('#picker').farbtastic('#color').hide();								
							});
							jQuery('#bg_color_hover').click(function(){
								jQuery('#menu_content_content_shortcode_button_menu_tbl').css("width","207px");
								jQuery('#picker4').farbtastic('#bg_color_hover').show();
								jQuery('#picker3').farbtastic('#text_color_hover').hide();
								jQuery('#picker2').farbtastic('#bgcolor').hide();
								jQuery('#picker').farbtastic('#color').hide();								
							});

						  });
							jQuery('<input type="button" class="button" value="Insert" />').appendTo($menu)
                                .click(function(){
                       
                                var uID =  Math.floor((Math.random()*100)+1);
                                var text = $menu.find('input[name=text]').val();
								var links = $menu.find('input[name=links]').val();
								var size = $menu.find('select[name=size]').val();
								//var style = $menu.find('select[name=style]').val();
								var icon = ($menu.find('input[name=icon]').val()) ? 'icon="'+$menu.find('input[name=icon]').val()+'"' : '';
								var text_color = ($menu.find('input[id=color]').val() && $menu.find('input[id=color]').val() != '#') ? 'text_color="'+$menu.find('input[id=color]').val()+'"' : '';
								
								var text_color_hover = ($menu.find('input[name=text_color_hover]').val() && $menu.find('input[name=text_color_hover]').val() != '#') ? 'text_color_hover="'+$menu.find('input[name=text_color_hover]').val()+'"' : '';
								
								var bg_color = ($menu.find('input[id=bgcolor]').val() && $menu.find('input[id=bgcolor]').val() != '#') ? 'bg_color="'+$menu.find('input[id=bgcolor]').val()+'"' : '';
								
								var bg_color_hover = ($menu.find('input[name=bg_color_hover]').val() && $menu.find('input[name=bg_color_hover]').val() != '#') ? 'bg_color_hover="'+$menu.find('input[name=bg_color_hover]').val()+'"' : '';
								
								var shortcode = '[button id="button_'+uID+'" size="'+size+'" link="'+links+'" '+icon+' '+text_color+' '+bg_color+' '+text_color_hover+' '+bg_color_hover+']'+text+'[/button]<br class="nc"/>';

                                    tinymce.activeEditor.execCommand('mceInsertContent',false,shortcode);
                                    c.hideMenu();
                                }).wrap('<tr><td><div style="padding: 0 10px 10px"></div></td></tr>')
                 
                        $menu.data('added',true); 

                    });

                   // XSmall
					m.add({title : 'Button', 'class' : 'mceMenuItemTitle'}).setDisabled(1);

                 });
                // Return the new splitbutton instance
                return c;
                
            }
            return null;
        }
    });
    tinymce.PluginManager.add('shortcode_button', tinymce.plugins.shortcode_button);
})();

function buttonstylechange(){
	$j = jQuery;	
	if($j('#button_style').val() == 'style-1' || $j('#button_style').val() == 'style-2' || $j('#button_style').val() == 'style-3'){
		$j('#text_color_span').html('Text color hover');
	}else{
		$j('#text_color_span').html('Text color');
	}
}

function trim(str) {
	return str.replace(/^\s+|\s+$/g,"");
}
/*tinyMCE.init({
	//...
	theme_advanced_text_colors : "FF00FF,FFFF00,000000"
});*/

/*jQuery('#order').ColorPicker({
	onSubmit: function(hsb, hex, rgb, el) {
		jQuery(el).val(hex);
		console.log(this);
		jQuery(el).ColorPickerHide();
	},
	onBeforeShow: function () {
		jQuery(this).ColorPickerSetColor(this.value);
	}
})
.bind('keyup', function(){
	jQuery(this).ColorPickerSetColor(this.value);
});
*/

