// JavaScript Document
(function() {
    // Creates a new plugin class and a custom listbox
    tinymce.create('tinymce.plugins.shortcode_tooltip', {
        createControl: function(n, cm) {
            switch (n) {                
                case 'shortcode_tooltip':
                var c = cm.createSplitButton('shortcode_tooltip', {
                    title : 'Tooltip',
                    onclick : function() {
                    }
                });

                c.onRenderMenu.add(function(c, m) {
                    m.onShowMenu.add(function(c,m){
                        jQuery('#menu_'+c.id).height('auto').width('auto');
                        jQuery('#menu_'+c.id+'_co').height('auto').addClass('mceListBoxMenu'); 
                        var $menu = jQuery('#menu_'+c.id+'_co').find('tbody:first');
                        if($menu.data('added')) return;
                        $menu.append('');
                        $menu.append('<tr><td><div style="padding:10px 10px 10px">\
						<label>Title<br />\
                        <input type="text" name="title" value="" /></label>\
                        </div></td></tr>');

                        jQuery('<input type="button" class="button" value="Insert" />').appendTo($menu)
                                .click(function(){
                       
                                var uID =  Math.floor((Math.random()*100)+1);
								var title = $menu.find('input[name=title]').val();
								var shortcode = '[tooltip id="tooltip_'+uID+'" title="'+title+'"]'+tinymce.activeEditor.selection.getContent()+'[/tooltip]';

                                    tinymce.activeEditor.execCommand('mceInsertContent',false,shortcode);
                                    c.hideMenu();
                                }).wrap('<tr><td><div style="padding: 0 10px 10px"></div></td></tr>')
                 
                        $menu.data('added',true); 

                    });

                   // XSmall
					m.add({title : 'Tooltip', 'class' : 'mceMenuItemTitle'}).setDisabled(1);

                 });
                // Return the new splitbutton instance
                return c;
                
            }
            return null;
        }
    });
    tinymce.PluginManager.add('shortcode_tooltip', tinymce.plugins.shortcode_tooltip);
})();

/*function buttonstylechange(){
	$j = jQuery;	
	if($j('#button_style').val() == 'style-1' || $j('#button_style').val() == 'style-2' || $j('#button_style').val() == 'style-3'){
		$j('#text_color_span').html('Text color hover');
	}else{
		$j('#text_color_span').html('Text color');
	}
}

*/
/*tinyMCE.init({
	//...
	theme_advanced_text_colors : "FF00FF,FFFF00,000000"
});*/

/*jQuery('#order').ColorPicker({
	onSubmit: function(hsb, hex, rgb, el) {
		jQuery(el).val(hex);
		console.log(this);
		jQuery(el).ColorPickerHide();
	},
	onBeforeShow: function () {
		jQuery(this).ColorPickerSetColor(this.value);
	}
})
.bind('keyup', function(){
	jQuery(this).ColorPickerSetColor(this.value);
});
*/

