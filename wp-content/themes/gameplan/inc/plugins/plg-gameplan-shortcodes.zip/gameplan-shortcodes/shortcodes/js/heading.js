// JavaScript Document
(function() {
    // Creates a new plugin class and a custom listbox
    tinymce.create('tinymce.plugins.ct_heading', {
        createControl: function(n, cm) {
            switch (n) {                
                case 'ct_heading':
                var c = cm.createSplitButton('ct_heading', {
                    title : 'Heading',
                    onclick : function() {
                    }
                });

                c.onRenderMenu.add(function(c, m) {
                    m.onShowMenu.add(function(c,m){
                        jQuery('#menu_'+c.id).height('auto').width('auto');
                        jQuery('#menu_'+c.id+'_co').height('auto').addClass('mceListBoxMenu'); 
                        var $menu = jQuery('#menu_'+c.id+'_co').find('tbody:first');
                        if($menu.data('added')) return;
                        $menu.append('');
                        $menu.append('<tr><td><div style="padding:10px 10px 10px">\
						<label>Icon in font <a style="display:inline;text-decoration:underline !important;cursor:pointer;" href="http://fortawesome.github.io/Font-Awesome/icons/">Awesome</a><br />\
						<i style="font-size:10px;">EX: icon-mobile-phone</i><br/>\
                        <input type="text" name="icon" value="" /></label>\
                        <label>Heading<br />\
                        <input type="text" name="heading" value="" /></label>\
						<div class="form-item"><label>Color<br />\
                        <input type="text" name="color" id="color12" value="#ee4422" /></label></div><div id="picker12"></div>\
						<label>First Word Different<br />\
						<select name="firstword">\
							<option value="yes">Yes</option>\
							<option value="no">No</option>\
						</select></label>\
						<label>Show dotted<br />\
						<select name="dotted">\
							<option value="yes">Yes</option>\
							<option value="no">No</option>\
						</select></label>\
                        </div></td></tr>');
						  jQuery(document).ready(function() {
							jQuery('#demo').hide();
							jQuery('#picker12').hide();
							jQuery('#color12').click(function(){
								jQuery('#menu_content_content_ct_heading_menu_tbl').css("width","207px");
								jQuery('#picker12').farbtastic('#color12').show();
							});
							jQuery('#color12').focusout(function(){
								jQuery('#menu_content_content_ct_heading_menu_tbl').css("width","auto");
								jQuery('#picker12').farbtastic('#color12').hide();
							});
						  });

                        jQuery('<input type="button" class="button" value="Insert" />').appendTo($menu)
                                .click(function(){
                       
                                var uID =  Math.floor((Math.random()*100)+1);
                                var icon = $menu.find('input[name=icon]').val();
								var heading = $menu.find('input[name=heading]').val();
								var color = $menu.find('input[name=color12]').val();																
								var firstword = $menu.find('select[name=firstword]').val();
								var dotted = $menu.find('select[name=dotted]').val();
								
								
								var shortcode = '[heading icon="'+icon+'" heading="'+heading+'" color="'+color+'" firstword="'+firstword+'" dotted="'+dotted+'"][/heading]<br class="nc"/>';

                                    tinymce.activeEditor.execCommand('mceInsertContent',false,shortcode);
                                    c.hideMenu();
                                }).wrap('<tr><td><div style="padding: 0 10px 10px"></div></td></tr>')
                 
                        $menu.data('added',true); 

                    });

                   // XSmall
					m.add({title : 'Heading', 'class' : 'mceMenuItemTitle'}).setDisabled(1);

                 });
                // Return the new splitbig_font_icon instance
                return c;
                
            }
            return null;
        }
    });
    tinymce.PluginManager.add('ct_heading', tinymce.plugins.ct_heading);
})();