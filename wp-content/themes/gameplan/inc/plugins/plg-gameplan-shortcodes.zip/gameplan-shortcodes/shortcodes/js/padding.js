// JavaScript Document
(function() {
    // Creates a new plugin class and a custom listbox
    tinymce.create('tinymce.plugins.shortcode_padding', {
        createControl: function(n, cm) {
            switch (n) {                
                case 'shortcode_padding':
                var c = cm.createSplitButton('shortcode_padding', {
                    title : 'Padding',
                    onclick : function() {
                    }
                });

                c.onRenderMenu.add(function(c, m) {
                    m.onShowMenu.add(function(c,m){
                        jQuery('#menu_'+c.id).height('auto').width('auto');
                        jQuery('#menu_'+c.id+'_co').height('auto').addClass('mceListBoxMenu'); 
                        var $menu = jQuery('#menu_'+c.id+'_co').find('tbody:first');
                        if($menu.data('added')) return;
                        $menu.append('');
                        $menu.append('<div style="padding:0 10px 10px">\
						<label>Margin Top<br />\
						<i style="font-size:10px;">EX: 10px</i><br/>\
						<input type="text" name="margin-top" value="" /></label>\
                        <label>Margin Bottom<br />\
						<i style="font-size:10px;">EX: 10px</i><br/>\
                        <input type="text" name="margin-bottom" value="" /></label>\
                        </div>');
							jQuery('<input type="button" class="button" value="Insert" />').appendTo($menu)
                                .click(function(){
                       
                                var uID =  Math.floor((Math.random()*100)+1);
                               	var margin_top  = $menu.find('input[name=margin-top]').val();
								var margin_bottom = $menu.find('input[name=margin-bottom]').val();
								var  shortcode= '[margin   top="'+margin_top+'" bottom="'+margin_bottom+'" ]';
                                    tinymce.activeEditor.execCommand('mceInsertContent',false,shortcode);
                                    c.hideMenu();
                                }).wrap('<tr><td><div style="padding: 0 10px 10px"></div></td></tr>')
                 
                        $menu.data('added',true); 

                    });
                   // XSmall
					m.add({title : 'Padding', 'class' : 'mceMenuItemTitle'}).setDisabled(1);

                 });
                // Return the new splitbutton instance
                return c;
                
            }
            return null;
        }
    });
    tinymce.PluginManager.add('shortcode_padding', tinymce.plugins.shortcode_padding);
})();
