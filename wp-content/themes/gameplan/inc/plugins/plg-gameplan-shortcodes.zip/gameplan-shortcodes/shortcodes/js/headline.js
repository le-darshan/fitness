// JavaScript Document
(function() {
    // Creates a new plugin class and a custom listbox
    tinymce.create('tinymce.plugins.shortcode_headline', {
        createControl: function(n, cm) {
            switch (n) {                
                case 'shortcode_headline':
                var c = cm.createSplitButton('shortcode_headline', {
                    title : 'Headline',
                    onclick : function() {
                    }
                });

                c.onRenderMenu.add(function(c, m) {
                    m.onShowMenu.add(function(c,m){
                        jQuery('#menu_'+c.id).height('auto').width('auto');
                        jQuery('#menu_'+c.id+'_co').height('auto').addClass('mceListBoxMenu'); 
                        var $menu = jQuery('#menu_'+c.id+'_co').find('tbody:first');
                        if($menu.data('added')) return;
                        $menu.append('');
                        $menu.append('<div style="padding:0 10px 10px">\
						<label>Number of post to show <br />\
						<input type="text" name="number" value="" /></label>\
                        <label>Categories ID<br />\
                        <input type="text" name="cat" value="" /></label>\
						<label>Post types<br />\
                        <input type="text" name="posttypes" value="" /></label>\
						<label>Icon in font <a style="display:inline;text-decoration:underline !important;cursor:pointer;" href="http://fortawesome.github.io/Font-Awesome/icons/">Awesome</a><br />\
						<i style="font-size:10px;">EX: icon-mobile-phone</i><br/>\
                        <input type="text" name="icon" value="" /></label>\
						<label>Link <br />\
						<select name="link">\
							<option value="yes">Yes</option>\
							<option value="no">No</option>\
						</select></label>\
						<label>Sort by<br />\
						<select name="sortby">\
							<option value="rand">random</option>\
							<option value="title">title</option>\
							<option value="date">date</option>\
						</select></label>\
						<div class="form-item"><label for="color1">Background Color</label><input type="text" name="color_headline" id="color_headline" value="#" /></div><div  id="picker_headline"></div>\
						<div class="form-item"><label for="color1">Background Color</label><input type="text" name="color_headline1" id="color_headline1" value="#" /></div><div  id="picker_headline1"></div>\
                        <div class="form-item"><label for="color1">Background Color</label><input type="text" name="color_headline2" id="color_headline2" value="#" /></div><div  id="picker_headline2"></div>\
						<label>Animation:<br />\
						<select name="animation">\
							<option value="">No</option>\
							<option value="top-to-bottom">Top to bottom</option>\
							<option value="bottom-to-top">Bottom to top</option>\
							<option value="left-to-right">Left to right</option>\
							<option value="right-to-left">Right to left</option>\
							<option value="appear">Appear</option>\
						</select></label>\
                        </div>');
						  jQuery(document).ready(function() {
							jQuery('#color_headline').click(function(){
								jQuery('#menu_content_content_shortcode_headline_menu_tbl').css("width","207px");
								jQuery('#picker_headline').farbtastic('#color_headline').show();
								jQuery('#picker_headline1').farbtastic('#color_headline1').hide();
								jQuery('#picker_headline2').farbtastic('#color_headline2').hide();
							});
							jQuery('#color_headline1').click(function(){
								jQuery('#menu_content_content_shortcode_headline_menu_tbl').css("width","207px");
								jQuery('#picker_headline1').farbtastic('#color_headline1').show();
								jQuery('#picker_headline').farbtastic('#color_headline').hide();
								jQuery('#picker_headline2').farbtastic('#color_headline2').hide();
							});
							jQuery('#color_headline2').click(function(){
								jQuery('#menu_content_content_shortcode_headline_menu_tbl').css("width","207px");
								jQuery('#picker_headline2').farbtastic('#color_headline2').show();
								jQuery('#picker_headline').farbtastic('#color_headline').hide();
								jQuery('#picker_headline1').farbtastic('#color_headline1').hide();
							});
						  });

							jQuery('<input type="button" class="button" value="Insert" />').appendTo($menu)
                                .click(function(){
                       
                                var uID =  Math.floor((Math.random()*100)+1);
                               	var number = $menu.find('input[name=number]').val();
								var cat = $menu.find('input[name=cat]').val();
								var posttypes = $menu.find('input[name=posttypes]').val();
								var icon = $menu.find('input[name=icon]').val();
								var linkshow = $menu.find('select[name=link]').val();
								var sortby = $menu.find('select[name=sortby]').val();
								var coloricon = ($menu.find('input[id=color_headline]').val()) ? 'coloricon="'+$menu.find('input[id=color_headline]').val()+'"' : '';
								var color = ($menu.find('input[id=color-icon1]').val()) ? 'color="'+$menu.find('input[id=color-icon1]').val()+'"' : '';
								var background = ($menu.find('input[id=color-icon2]').val()) ? 'background="'+$menu.find('input[id=color-icon2]').val()+'"' : '';
								var animation = $menu.find('select[name=animation]').val();
								var  shortcode= '[headline  number="'+number+'" posttypes="'+posttypes+'" icon="'+icon+'" link="'+linkshow+'" sortby="'+sortby+'" '+coloricon+' '+color+' '+background+' animation="'+ animation +'"]';
                                    tinymce.activeEditor.execCommand('mceInsertContent',false,shortcode);
                                    c.hideMenu();
                                }).wrap('<tr><td><div style="padding: 0 10px 10px"></div></td></tr>')
                 
                        $menu.data('added',true); 

                    });
                   // XSmall
					m.add({title : 'Headline', 'class' : 'mceMenuItemTitle'}).setDisabled(1);

                 });
                // Return the new splitbutton instance
                return c;
                
            }
            return null;
        }
    });
    tinymce.PluginManager.add('shortcode_headline', tinymce.plugins.shortcode_headline);
})();
