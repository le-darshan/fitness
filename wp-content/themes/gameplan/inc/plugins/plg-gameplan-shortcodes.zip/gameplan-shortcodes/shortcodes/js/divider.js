// JavaScript Document
(function() {
    // Creates a new plugin class and a custom listbox
    tinymce.create('tinymce.plugins.shortcode_divider', {
        createControl: function(n, cm) {
            switch (n) {                
                case 'shortcode_divider':
                var c = cm.createSplitButton('shortcode_divider', {
                    title : 'Divider',
                    onclick : function() {
                    }
                });

                c.onRenderMenu.add(function(c, m) {
                    m.onShowMenu.add(function(c,m){
                        jQuery('#menu_'+c.id).height('auto').width('auto');
                        jQuery('#menu_'+c.id+'_co').height('auto').addClass('mceListBoxMenu'); 
                        var $menu = jQuery('#menu_'+c.id+'_co').find('tbody:first');
                        if($menu.data('added')) return;
                        $menu.append('');
                        $menu.append('<div style="padding:0 10px 10px">\
						<label>Color style<br />\
						<select name="colorstyle">\
							<option value="colorstyle_1">Light</option>\
							<option value="colorstyle_2">Dark</option>\
						</select></label>\
						<label>Divider style<br />\
						<select name="style">\
							<option value="style_1">Dotted</option>\
							<option value="style_2">Double dotted</option>\
							<option value="style_3">Solid grey</option>\
							<option value="style_4">1px Solid grey</option>\
							<option value="style_5">Solid color</option>\
							<option value="style_6">Drop shadow</option>\
						</select></label>\
						<label>Padding top<br />\
						<i style="font-size:10px;">EX:10. Default:20</i><br/>\
						<input type="text" name="paddingtop" value="" /></label>\
						<label>Padding bottom<br />\
						<i style="font-size:10px;">EX:10. Default:20</i><br/>\
						<input type="text" name="paddingbottom" value="" /></label>\
						<label>Animation<br />\
						<select name="animation">\
							<option value="">No</option>\
							<option value="top-to-bottom">Top to bottom</option>\
							<option value="bottom-to-top">Bottom to top</option>\
							<option value="left-to-right">Left to right</option>\
							<option value="right-to-left">Right to left</option>\
							<option value="appear">Appear</option>\
						</select></label>\
                        </div>');
							jQuery('<input type="button" class="button" value="Insert" />').appendTo($menu)
                                .click(function(){
                       
                                var uID =  Math.floor((Math.random()*100)+1);
                                var colorstyle = $menu.find('select[name=colorstyle]').val();
								var style = $menu.find('select[name=style]').val();
								var paddingtop = $menu.find('input[name=paddingtop]').val();
								var paddingbottom = $menu.find('input[name=paddingbottom]').val();
								var animation = $menu.find('select[name=animation]').val();
								var shortcode = '[divider colorstyle="'+colorstyle+'" dividerstyle="'+style+'" paddingtop="'+paddingtop+'" paddingbottom="'+paddingbottom+'" animation="'+animation+'" ]<br class="nc"/>';
								
                                    tinymce.activeEditor.execCommand('mceInsertContent',false,shortcode);
                                    c.hideMenu();
                                }).wrap('<tr><td><div style="padding: 0 10px 10px"></div></td></tr>')
                 
                        $menu.data('added',true); 

                    });
                   // XSmall
					m.add({title : 'Divider', 'class' : 'mceMenuItemTitle'}).setDisabled(1);

                 });
                // Return the new splitbutton instance
                return c;
                
            }
            return null;
        }
    });
    tinymce.PluginManager.add('shortcode_divider', tinymce.plugins.shortcode_divider);
})();
