// JavaScript Document
(function() {
    // Creates a new plugin class and a custom listbox
    tinymce.create('tinymce.plugins.ct_font_icons', {
        createControl: function(n, cm) {
            switch (n) {                
                case 'ct_font_icons':
                var c = cm.createSplitButton('ct_font_icons', {
                    title : 'Icon',
                    onclick : function() {
                    }
                });

                c.onRenderMenu.add(function(c, m) {
                    m.onShowMenu.add(function(c,m){
                        jQuery('#menu_'+c.id).height('auto').width('auto');
                        jQuery('#menu_'+c.id+'_co').height('auto').addClass('mceListBoxMenu'); 
                        var $menu = jQuery('#menu_'+c.id+'_co').find('tbody:first');
                        if($menu.data('added')) return;
                        $menu.append('');
                        $menu.append('<tr><td><div style="padding:10px 10px 10px">\
						<label>Icon in font <a style="display:inline;text-decoration:underline !important;cursor:pointer;" href="http://fortawesome.github.io/Font-Awesome/icons/">Awesome</a><br />\
						<i style="font-size:10px;">EX: icon-mobile-phone</i><br/>\
                        <input type="text" name="icon" value="" /></label>\
                        <label>Icon Effect<br />\
						<select name="effect">\
							<option value="effect-1">Effect 1</option>\
							<option value="effect-2">Effect 2</option>\
						</select></label>\
						<label>Icon Size<br />\
						<select name="size">\
							<option value="big">Big</option>\
							<option value="small">Small</option>\
						</select></label>\
						<label>Icon type<br />\
						<select name="type">\
							<option value="circle">Circle</option>\
							<option value="square">Square</option>\
						</select></label>\
						<label>Icon Link<br />\
						<i style="font-size:10px;">Include "http://" before your link</i><br/>\
                        <input type="text" name="link" value="" /></label>\
						<div class="form-item"><label for="color">Icon color</label><input type="text" id="color5" name="color" value="#" /></div><div id="picker5"></div>\
						<div class="form-item"><label for="color">Background Color</label><input type="text" id="bgcolor6" name="color" value="#" /></div><div id="picker6"></div>\
                        </div></td></tr>');
						  jQuery(document).ready(function() {
							jQuery('#demo').hide();
							jQuery('#picker5').hide();
							jQuery('#color5').click(function(){
								jQuery('#menu_content_content_ct_font_icons_menu_tbl').css("width","207px");
								jQuery('#picker5').farbtastic('#color5').show();
								jQuery('#picker6').farbtastic('#bgcolor6').hide();
							});
							jQuery('#color5').focusout(function(){
								jQuery('#menu_content_content_ct_font_icons_menu_tbl').css("width","auto");
								jQuery('#picker5').farbtastic('#color5').hide();
							});
							jQuery('#bgcolor6').click(function(){
								jQuery('#menu_content_content_ct_font_icons_menu_tbl').css("width","207px");
								jQuery('#picker6').farbtastic('#bgcolor6').show();
								jQuery('#picker5').farbtastic('#color5').hide();
							});

						  });

                        jQuery('<input type="button" class="button" value="Insert" />').appendTo($menu)
                                .click(function(){
                       
                                var uID =  Math.floor((Math.random()*100)+1);
                                var icon = $menu.find('input[name=icon]').val();								
								var effect = $menu.find('select[name=effect]').val();
								var size = ($menu.find('select[name=size]').val()) ? 'size="'+$menu.find('select[name=size]').val()+'"' : '';
								var type = ($menu.find('select[name=type]').val()) ? 'type="'+$menu.find('select[name=type]').val()+'"' : '';
								var links = ($menu.find('input[name=link]').val()) ? 'link="'+$menu.find('input[name=link]').val()+'"' : '';
								var text_color = ($menu.find('input[id=color5]').val() && $menu.find('input[id=color5]').val() != '#') ? 'text_color="'+$menu.find('input[id=color5]').val()+'"' : '';
								var bg_color = ($menu.find('input[id=bgcolor6]').val() && $menu.find('input[id=bgcolor6]').val() != '#') ? 'bg_color="'+$menu.find('input[id=bgcolor6]').val()+'"' : '';
								
								var shortcode = '[cticon id="icon_'+uID+'" effect="'+effect+'" '+size+' icon="'+icon+'" '+text_color+' '+bg_color+' '+links+' '+type+'][/cticon]<br class="nc"/>';

                                    tinymce.activeEditor.execCommand('mceInsertContent',false,shortcode);
                                    c.hideMenu();
                                }).wrap('<tr><td><div style="padding: 0 10px 10px"></div></td></tr>')
                 
                        $menu.data('added',true); 

                    });

                   // XSmall
					m.add({title : 'Icon', 'class' : 'mceMenuItemTitle'}).setDisabled(1);

                 });
                // Return the new splitbig_font_icon instance
                return c;
                
            }
            return null;
        }
    });
    tinymce.PluginManager.add('ct_font_icons', tinymce.plugins.ct_font_icons);
})();