// JavaScript Document
(function() {
    // Creates a new plugin class and a custom listbox
    tinymce.create('tinymce.plugins.shortcode_facelike', {
        createControl: function(n, cm) {
            switch (n) {                
                case 'shortcode_facelike':
                var c = cm.createSplitButton('shortcode_facelike', {
                    title : 'Button like fakebook',
                    onclick : function() {
                    }
                });

                c.onRenderMenu.add(function(c, m) {
                    m.onShowMenu.add(function(c,m){
                        jQuery('#menu_'+c.id).height('auto').width('auto');
                        jQuery('#menu_'+c.id+'_co').height('auto').addClass('mceListBoxMenu'); 
                        var $menu = jQuery('#menu_'+c.id+'_co').find('tbody:first');
                        if($menu.data('added')) return;
                        $menu.append('');
                        $menu.append('<tr><td><div style="padding:10px 10px 10px">\
						<label>Facebook Page URL<br />\
                        <input type="text" name="links" value="" /></label>\
 						<label>Width<br />\
						<i style="font-size:10px;">EX: 100. Default:450</i><br/>\
                        <input type="text" name="width" value="" /></label>\
                       <label>Layout Style<br />\
						<select name="layout">\
							<option value="standard">Standard</option>\
							<option value="button_count">button_count</option>\
							<option value="box_count">box_count</option>\
						</select></label>\
                        <label>Color Scheme<br />\
						<select name="colorscheme">\
							<option value="light">light</option>\
							<option value="dark">dark</option>\
						</select></label>\
						<label>Send Button<br />\
						<select name="btnsend">\
							<option value="true">true</option>\
							<option value="false">false</option>\
						</select></label>\
						<label>Show faces<br />\
						<select name="btnshow">\
							<option value="true">true</option>\
							<option value="false">false</option>\
						</select></label>\
                        </div></td></tr>');

                        jQuery('<input type="button" class="button" value="Insert" />').appendTo($menu)
                                .click(function(){
                       
                                var uID =  Math.floor((Math.random()*100)+1);
								var links = $menu.find('input[name=links]').val();
								var width = $menu.find('input[name=width]').val();
								var layout = $menu.find('select[name=layout]').val();
								var colorscheme = $menu.find('select[name=colorscheme]').val();
								var sendbutton = $menu.find('select[name=btnsend]').val();
								var showfaces = $menu.find('select[name=btnshow]').val();
								if(width=='')
								{
									width=450;
								}
								var shortcode = '[facebook id="facebook_'+uID+'" links="'+links+'" width="'+width+'" layout="'+layout+'"  colorscheme="'+colorscheme+'" sendbutton="'+sendbutton+'" showfaces="'+showfaces+'" ]<br class="nc"/>';

                                    tinymce.activeEditor.execCommand('mceInsertContent',false,shortcode);
                                    c.hideMenu();
                                }).wrap('<tr><td><div style="padding: 0 10px 10px"></div></td></tr>')
                 
                        $menu.data('added',true); 

                    });

                   // XSmall
					m.add({title : 'Facebook like button', 'class' : 'mceMenuItemTitle'}).setDisabled(1);

                 });
                // Return the new splitbutton instance
                return c;
                
            }
            return null;
        }
    });
    tinymce.PluginManager.add('shortcode_facelike', tinymce.plugins.shortcode_facelike);
})();

/*function buttonstylechange(){
	$j = jQuery;	
	if($j('#button_style').val() == 'style-1' || $j('#button_style').val() == 'style-2' || $j('#button_style').val() == 'style-3'){
		$j('#text_color_span').html('Text color hover');
	}else{
		$j('#text_color_span').html('Text color');
	}
}

*/
/*tinyMCE.init({
	//...
	theme_advanced_text_colors : "FF00FF,FFFF00,000000"
});*/

/*jQuery('#order').ColorPicker({
	onSubmit: function(hsb, hex, rgb, el) {
		jQuery(el).val(hex);
		console.log(this);
		jQuery(el).ColorPickerHide();
	},
	onBeforeShow: function () {
		jQuery(this).ColorPickerSetColor(this.value);
	}
})
.bind('keyup', function(){
	jQuery(this).ColorPickerSetColor(this.value);
});
*/
