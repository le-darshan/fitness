// JavaScript Document
(function() {
    // Creates a new plugin class and a custom listbox
    tinymce.create('tinymce.plugins.shortcode_testimonial', {
        createControl: function(n, cm) {
            switch (n) {                
                case 'shortcode_testimonial':
                var c = cm.createSplitButton('shortcode_testimonial', {
                    title : 'Testimonial',
                    onclick : function() {
                    }
                });

                c.onRenderMenu.add(function(c, m) {
                    m.onShowMenu.add(function(c,m){
                        jQuery('#menu_'+c.id).height('auto').width('auto');
                        jQuery('#menu_'+c.id+'_co').height('auto').addClass('mceListBoxMenu'); 
                        var $menu = jQuery('#menu_'+c.id+'_co').find('tbody:first');
                        if($menu.data('added')) return;
                        $menu.append('');
                        $menu.append('<tr><td><div style="padding:10px 10px 10px">\
						<label>Number of Item<br />\
						<i style="font-size:10px;">EX: 3</i><br/>\
                        <input type="text" name="number" value="" /></label>\
						<label>Animation<br />\
						<select name="animation">\
							<option value="">No</option>\
							<option value="top-to-bottom">Top to bottom</option>\
							<option value="bottom-to-top">Bottom to top</option>\
							<option value="left-to-right">Left to right</option>\
							<option value="right-to-left">Right to left</option>\
							<option value="appear">Appear</option>\
						</select></label>\
                        </div></td></tr>');

                        jQuery('<input type="button" class="button" value="Insert" />').appendTo($menu)
                                .click(function(){
                       
                                var uID =  Math.floor((Math.random()*100)+1);
                                var number = $menu.find('input[name=number]').val();
								var animation = $menu.find('select[name=animation]').val();
								var shortcode = '[testimonial]<br class="nc"/>';
								for(i=0;i<number;i++){
									j=i+1;
                                        shortcode+= '[testimonial_item  title="Testimonial title ' + j + '" name="Testimonial name '+j+' " position="Testimonial position '+j+' " company="Testimonial company '+j+' " animation="'+animation+'"]Content here[/testimonial_item]<br class="nc"/>';
                                    }
                                shortcode+= '[/testimonial]<br class="nc"/>';
								

                                    tinymce.activeEditor.execCommand('mceInsertContent',false,shortcode);
                                    c.hideMenu();
                                }).wrap('<tr><td><div style="padding: 0 10px 10px"></div></td></tr>')
                 
                        $menu.data('added',true); 

                    });

                   // XSmall
					m.add({title : 'Testimonial', 'class' : 'mceMenuItemTitle'}).setDisabled(1);

                 });
                // Return the new splitbig_font_icon instance
                return c;
                
            }
            return null;
        }
    });
    tinymce.PluginManager.add('shortcode_testimonial', tinymce.plugins.shortcode_testimonial);
})();