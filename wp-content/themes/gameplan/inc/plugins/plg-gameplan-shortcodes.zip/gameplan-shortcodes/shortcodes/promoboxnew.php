<?php
/**
 * WPBakery Visual Composer shortcodes
 *
 * @package WPBakeryVisualComposer
 *
 */

class WPBakeryShortCode_PromoBoxNew_item extends WPBakeryShortCode_VC_Tab {
    protected  $predefined_atts = array(
        //'el_class' => '',
        //'width' => '',
        //'title' => '',
		'title' => '',
		'backround' => '',
		'link' => '',
    );
/*fff*/
    public function content( $atts, $content = null ) {
        global $promoboxnew_slides;
		global $promoboxnew_slides_number;
		//$el_class = $this->getExtraClass($el_class);
		$output = '';
		if($promoboxnew_slides_number == 2){
			$span_class = 'span6';
		}elseif($promoboxnew_slides_number == 3){
			$span_class = 'span4';
		}elseif($promoboxnew_slides_number == 4){
			$span_class = 'span3';
		}elseif($promoboxnew_slides_number == 6){
			$span_class = 'span2';
		}else{
			$span_class = 'span4';
		}
		if(isset($atts['background'])&&$atts['background']){
			$background = wp_get_attachment_image_src( $atts['background'], 'full' );
			$output .= '<div class="promoboxnew-item '.$span_class.'" style="background-image:url('.$background[0].')">';
		}else{
			$output .= '<div class="promoboxnew-item span4">';
		}
		if(isset($atts['link'])&&$atts['link']){
			$output .= '<a href="'.$atts['link'].'">';
		}
		$output .= '<div class="promoboxnew-item-inner">';
		$output .= '<h3 class="promoboxnew-item-heading"><i class="icon-caret-left"></i>'.$atts['title'].'</h3>';
		$output .= '<div class="promoboxnew-item-content">';
		$output .= strip_tags($content,'<h1><h2><h3><h4><h5>');
		$output .= '</div>';
		$output .= '</div>';
		if(isset($atts['link'])&&$atts['link']){
			$output .= '</a>';
		}
		$output .= '</div>';
        return $output;
    }


/*fff*/

    public function contentAdmin($atts, $content = null) {
        $width = $el_class = $title = '';
        extract(shortcode_atts($this->predefined_atts, $atts));
        $output = '';

        $column_controls = $this->getColumnControls($this->settings('controls'));
        $column_controls_bottom =  $this->getColumnControls('add', 'bottom-controls');

        if ( $width == 'column_14' || $width == '1/4' ) {
            $width = array('span3');
        }
        else if ( $width == 'column_14-14-14-14' ) {
            $width = array('span3', 'span3', 'span3', 'span3');
        }

        else if ( $width == 'column_13' || $width == '1/3' ) {
            $width = array('span4');
        }
        else if ( $width == 'column_13-23' ) {
            $width = array('span4', 'span8');
        }
        else if ( $width == 'column_13-13-13' ) {
            $width = array('span4', 'span4', 'span4');
        }

        else if ( $width == 'column_12' || $width == '1/2' ) {
            $width = array('span6');
        }
        else if ( $width == 'column_12-12' ) {
            $width = array('span6', 'span6');
        }

        else if ( $width == 'column_23' || $width == '2/3' ) {
            $width = array('span8');
        }
        else if ( $width == 'column_34' || $width == '3/4' ) {
            $width = array('span9');
        }
        else if ( $width == 'column_16' || $width == '1/6' ) {
            $width = array('span2');
        }
        else {
            $width = array('');
        }


        for ( $i=0; $i < count($width); $i++ ) {
		$output .= '<div class="group wpb_sortable">';
			$output .= '<h3><span class="tab-label"><%= params.title %></span></h3>';
			$output .= '<div '.$this->mainHtmlBlockParams($width, 0).'>';
				$output .= str_replace("%column_size%", wpb_translateColumnWidthToFractional($width[0]), $column_controls);
				$output .= '<div class="wpb_element_wrapper">';
					$output .= '<div '.$this->containerHtmlBlockParams($width, 0).'>';
						$output .= '<%= params.text %>';
						$output .= do_shortcode( shortcode_unautop($content) );
						$output .= WPBakeryVisualComposer::getInstance()->getLayout()->getContainerHelper();
					$output .= '</div>';
					
					if ( isset($this->settings['params']) ) {
						$inner = '';
						foreach ($this->settings['params'] as $param) {
							$param_value = isset($$param['param_name']) ? $$param['param_name'] : '';
							if ( is_array($param_value)) {
								// Get first element from the array
								reset($param_value);
								$first_key = key($param_value);
								$param_value = $param_value[$first_key];
							}
							$inner .= $this->singleParamHtmlHolder($param, $param_value);
						}
						$output .= $inner;
					}
				$output .= '</div>';
				$output .= str_replace("%column_size%", wpb_translateColumnWidthToFractional($width[$i]), $column_controls_bottom);
			$output .= '</div>';
		$output .= '</div>';
		}	
        return $output;

    }

	public function mainHtmlBlockParams($width, $i) {
        return 'data-element_type="'.$this->settings["base"].'" class="' . $this->settings['class'] . ' wpb_'.$this->settings['base'].'"'.$this->customAdminBlockParams();
    }
    public function containerHtmlBlockParams($width, $i) {
        return 'class="wpb_column_container"';
    }
	
	public function contentAdmin_old($atts, $content = null) {
        $width = $el_class = $title = '';
        extract(shortcode_atts($this->predefined_atts, $atts));
        $output = '';
        $column_controls = $this->getColumnControls($this->settings('controls'));
        for ( $i=0; $i < count($width); $i++ ) {
            $output .= '<div class="group wpb_sortable">';
            $output .= '<div class="wpb_element_wrapper">';
            $output .= '<div class="vc_row-fluid wpb_row_container">';
            $output .= '<h3><a href="#">'.$title.'</a></h3>';
            $output .= '<div '.$this->customAdminBockParams().' data-element_type="'.$this->settings["base"].'" class=" wpb_'.$this->settings['base'].' wpb_sortable">';
            $output .= '<div class="wpb_element_wrapper">';
            $output .= '<div class="vc_row-fluid wpb_row_container">';
            $output .= do_shortcode( shortcode_unautop($content) );
            $output .= '</div>';
            if ( isset($this->settings['params']) ) {
                $inner = '';
                foreach ($this->settings['params'] as $param) {
                    $param_value = isset($$param['param_name']) ? $$param['param_name'] : '';
                    if ( is_array($param_value)) {
                        // Get first element from the array
                        reset($param_value);
                        $first_key = key($param_value);
                        $param_value = $param_value[$first_key];
                    }
                    $inner .= $this->singleParamHtmlHolder($param, $param_value);
                }
                $output .= $inner;
            }
            $output .= '</div>';
            $output .= '</div>';
            $output .= '</div>';
            $output .= '</div>';
            $output .= '</div>';
        }

        return $output;
    }

    protected function outputTitle($title) {
        return  '';
    }

    public function customAdminBlockParams() {
        return '';
    }

}
wpb_map( array(
    "name"		=> __("Promo item", "cactusthemes"),
    "base"		=> "promoboxnew_item",
    "class"		=> "wpb_vc_accordion_tab",
    "icon"      => "",
    "wrapper_class" => "",
    "controls"	=> "full",
    "content_element" => false,
    "params"	=> array(
        array(
            "type" => "textfield",
            "heading" => __("Title", "cactusthemes"),
            "param_name" => "title",
            "value" => "",
            "description" => '',
        ),
        array(
            "type" => "attach_image",
            "heading" => __("Background", "cactusthemes"),
            "param_name" => "background",
            "value" => "",
            "description" => '',
        ),
        array(
            "type" => "textarea_html",
            "holder" => "div",
            "class" => "",
            "heading" => __("Content", "cactusthemes"),
            "param_name" => "content",
            "value" => '',
            "description" => '',
        ),
		array(
            "type" => "textfield",
            "heading" => __("Link to go", "cactusthemes"),
            "param_name" => "link",
            "value" => "",
            "description" => '',
        ),
    ),
	'js_view'=>'VcPromoboxnewItemView'
) );

class WPBakeryShortCode_PromoBoxNew extends WPBakeryShortCode {

    public function __construct($settings) {
        parent::__construct($settings);
        // WPBakeryVisualComposer::getInstance()->addShortCode( array( 'base' => 'vc_accordion_tab' ) );
    }

    protected function content( $atts, $content = null ) {
		global $promoboxnew_slides;
        $title = $interval = $width = $el_position = $el_class = $animation_class = '';
        //
        extract(shortcode_atts(array(
            'title' => '',
            'interval' => 0,
            'width' => '1/1',
            'el_position' => '',
            'el_class' => '',
			'animation' => '',
        ), $atts));
        $output = '';
		if(class_exists('Mobile_Detect')){
			$detect = new Mobile_Detect;
			$_device_ = $detect->isMobile() ? ($detect->isTablet() ? 'tablet' : 'mobile') : 'pc';
			if(isset($atts['animation'])){
			$animation_class = ($atts['animation']&&$_device_=='pc')?'wpb_'.$atts['animation'].' wpb_animate_when_almost_visible':'';
			}
		}else{
			if(isset($atts['animation'])){
			$animation_class = $atts['animation']?'wpb_'.$atts['animation'].' wpb_animate_when_almost_visible':'';
			}
		}
        $el_class = $this->getExtraClass($el_class);
        str_replace("[promoboxnew_item","",$content,$i);
		global $promoboxnew_slides_number;
		$promoboxnew_slides_number = $i;
		$output .= '<div class="promoboxnew '.$animation_class.'"><div class="promoboxnew-inner"><div class="row">';
		$output .= "\n\t\t\t".wpb_js_remove_wpautop($content);
		$output .= '</div></div></div>';
		
        $output = $this->startRow($el_position) . $output . $this->endRow($el_position);
        return $output;

    }

    public function contentAdmin( $atts, $content ) {
        $width = $custom_markup = '';
        $shortcode_attributes = array('width' => '1/1');
        foreach ( $this->settings['params'] as $param ) {
            if ( $param['param_name'] != 'content' ) {
                if ( is_string($param['value']) ) {
                    $shortcode_attributes[$param['param_name']] = __($param['value'], "js_composer");
                } else {
                    $shortcode_attributes[$param['param_name']] = $param['value'];
                }
            } else if ( $param['param_name'] == 'content' && $content == NULL ) {
                $content = __($param['value'], "js_composer");
            }
        }
        extract(shortcode_atts(
            $shortcode_attributes
            , $atts));

        $output = '';

        $elem = $this->getElementHolder($width);

        $iner = '';
        foreach ($this->settings['params'] as $param) {
            $param_value = '';
            $param_value = $$param['param_name'];
            if ( is_array($param_value)) {
                // Get first element from the array
                reset($param_value);
                $first_key = key($param_value);
                $param_value = $param_value[$first_key];
            }
            $iner .= $this->singleParamHtmlHolder($param, $param_value);
        }
        //$elem = str_ireplace('%wpb_element_content%', $iner, $elem);
        $tmp = '';
       // $template = '<div class="wpb_template">'.do_shortcode('[testimonial_item name="New Section"][/testimonial_item]').'</div>';

        if ( isset($this->settings["custom_markup"]) && $this->settings["custom_markup"] != '' ) {
			
            if ( $content != '' ) {
                $custom_markup = str_ireplace("%content%", $tmp.$content, $this->settings["custom_markup"]);
            } else if ( $content == '' && isset($this->settings["default_content_in_template"]) && $this->settings["default_content_in_template"] != '' ) {
                $custom_markup = str_ireplace("%content%", $this->settings["default_content_in_template"], $this->settings["custom_markup"]);
            } else {
                $custom_markup =  str_ireplace("%content%", '', $this->settings["custom_markup"]);
            }
            //$output .= do_shortcode($this->settings["custom_markup"]);
            $inner .= do_shortcode($custom_markup);
        }
        $elem = str_ireplace('%wpb_element_content%', $inner, $elem);
        $output = $elem;

        return $output;
    }
}
wpb_map( array(
    "name"		=> __("Promo Box", "cactusthemes"),
    "base"		=> "promoboxnew",
    "controls"	=> "full",
    "show_settings_on_create" => false,
	"is_container" => true,
    "class"		=> "wpb_vc_accordion vc_not_inner_content wpb_container_block",
	//"icon"		=> "icon-wpb-ui-testimonial",
	"category"  => __('Content', "cactusthemes"),
//	"wrapper_class" => "clearfix",
    "params"	=> array(
        array(
            "type" => "textfield",
            "heading" => __("Name", "cactusthemes"),
            "param_name" => "name",
            "value" => "",
            "description" => '',
        ),
		array(		
			"type" => "dropdown",
			"holder" => "div",
			"class" => "",
			"heading" => __("CSS Animation", 'cactusthemes'),
			"param_name" => "animation",
			"value" => array(
				__("No", 'cactusthemes') => '',
				__("Top to bottom", 'cactusthemes') => 'top-to-bottom',
				__("Bottom to top", 'cactusthemes') => 'bottom-to-top',
				__("Left to right", 'cactusthemes') => 'left-to-right',
				__("Right to left", 'cactusthemes') => 'right-to-left',
				__("Appear from center", 'cactusthemes') => 'appear',
			),
			"description" => ''
		),
    ),
    "custom_markup" => '

	<div class="wpb_accordion_holder wpb_holder clearfix vc_container_for_children">
		%content%
	</div>
    <div class="tab_controls">
		<button class="add_tab" title="'.__("Add Promo Box section", "cactusthemes").'">'.__("Add Promo Box section", "cactusthemes").'</button>
  </div>',
    'default_content' => '
     [promoboxnew_item title="Promo item 1"][/promoboxnew_item]
    ',
	'js_view' => 'VcPromoboxnewView'
) );

