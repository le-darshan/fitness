// JavaScript Document
(function() {
    // Creates a new plugin class and a custom listbox
    tinymce.create('tinymce.plugins.shortcode_recentpost', {
        createControl: function(n, cm) {
            switch (n) {                
                case 'shortcode_recentpost':
                var c = cm.createSplitButton('shortcode_recentpost', {
                    title : 'Recent post',
                    onclick : function() {
                    }
                });

                c.onRenderMenu.add(function(c, m) {
                    m.onShowMenu.add(function(c,m){
                        jQuery('#menu_'+c.id).height('auto').width('auto');
                        jQuery('#menu_'+c.id+'_co').height('auto').addClass('mceListBoxMenu'); 
                        var $menu = jQuery('#menu_'+c.id+'_co').find('tbody:first');
                        if($menu.data('added')) return;
                        $menu.append('');
                        $menu.append('<div style="padding:0 10px 10px">\
						<label>Show metadata <br />\
						<select name="showmetadata">\
							<option value="1">Yes</option>\
							<option value="0">No</option>\
						</select></label>\
						<label>Posts count<br />\
						<input type="text" name="count" value="" /></label>\
						<label>Width per post<br />\
						<i style="font-size:10px;">Width of post in slide (> 100). Ex: 260</i><br/>\
                        <input type="text" name="width" value="" /></label>\
						<label>Post types<br />\
                        <input type="text" name="posttypes" value="" /></label>\
						<label>Post/Page IDs<br />\
                        <input type="text" name="posts_in" value="" /></label>\
						<label>Categories<br />\
                        <input type="text" name="categories" value="" /></label>\
						<label>Order by<br />\
						<select name="orderby">\
							<option value="date">date</option>\
							<option value="ID">ID</option>\
							<option value="author">random</option>\
							<option value="title">Title</option>\
							<option value="modified">Modified</option>\
							<option value="rand">random</option>\
							<option value="comment_count">Comment count</option>\
							<option value="menu_order">Menu order</option>\
						</select></label>\
						<label>Order by<br />\
						<select name="orderby_da">\
							<option value="DESC">Descending</option>\
							<option value="Ascending">ASC</option>\
						</select></label>\
						<label>Extra class name<br />\
                        <input type="text" name="el_class" value="" /></label>\
						<label>Animation:<br />\
						<select name="animation">\
							<option value="">No</option>\
							<option value="top-to-bottom">Top to bottom</option>\
							<option value="bottom-to-top">Bottom to top</option>\
							<option value="left-to-right">Left to right</option>\
							<option value="right-to-left">Right to left</option>\
							<option value="appear">Appear</option>\
						</select></label>\
                        </div>');
							jQuery('<input type="button" class="button" value="Insert" />').appendTo($menu)
                                .click(function(){
                       
                                var uID =  Math.floor((Math.random()*100)+1);
								var showmetadata = $menu.find('select[name=showmetadata]').val();
                               	var count = $menu.find('input[name=count]').val();
								var width = $menu.find('input[name=width]').val();
								var posttypes = $menu.find('input[name=posttypes]').val();
								var posts_in = $menu.find('input[name=posts_in]').val();
								var categories = $menu.find('input[name=categories]').val();
								var orderby = $menu.find('select[name=orderby]').val();
								var orderby_da = $menu.find('select[name=orderby_da]').val();
								var el_class = $menu.find('input[name=el_class]').val();
								var animation = $menu.find('select[name=animation]').val();
								var  shortcode= '[recent-post showmetadata="'+showmetadata+'" count="'+count+'" width="'+width+'"  posts_in="'+posts_in+'" orderby="'+orderby+'" order="'+orderby_da+'" el_class="'+el_class+'" posttypes="'+posttypes+'" categories="'+categories+'" animation="'+ animation +'"]';
                                    tinymce.activeEditor.execCommand('mceInsertContent',false,shortcode);
                                    c.hideMenu();
                                }).wrap('<tr><td><div style="padding: 0 10px 10px"></div></td></tr>')
                 
                        $menu.data('added',true); 

                    });
                   // XSmall
					m.add({title : 'Recen post', 'class' : 'mceMenuItemTitle'}).setDisabled(1);

                 });
                // Return the new splitbutton instance
                return c;
                
            }
            return null;
        }
    });
    tinymce.PluginManager.add('shortcode_recentpost', tinymce.plugins.shortcode_recentpost);
})();
