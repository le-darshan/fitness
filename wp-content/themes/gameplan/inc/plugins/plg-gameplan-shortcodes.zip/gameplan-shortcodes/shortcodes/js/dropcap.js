// JavaScript Document
(function() {
    // Creates a new plugin class and a custom listbox
    tinymce.create('tinymce.plugins.ct_dropcap', {
        createControl: function(n, cm) {
            switch (n) {                
                case 'ct_dropcap':
					var c = cm.createButton('ct_dropcap', {
						title : 'Dropcap',
						onclick : function() {
							var shortcode = '[dropcap]'+tinymce.activeEditor.selection.getContent()+'[/dropcap]';
							tinymce.activeEditor.execCommand('mceInsertContent',false,shortcode);
							c.hideMenu();
						}
					});
                // Return the new splitbig_font_icon instance
                return c;
                
            }
            return null;
        }
    });
    tinymce.PluginManager.add('ct_dropcap', tinymce.plugins.ct_dropcap);
})();