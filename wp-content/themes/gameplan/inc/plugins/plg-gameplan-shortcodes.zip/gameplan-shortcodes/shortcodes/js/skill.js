// JavaScript Document
(function() {
    // Creates a new plugin class and a custom listbox
    tinymce.create('tinymce.plugins.shortcode_skill', {
        createControl: function(n, cm) {
            switch (n) {                
                case 'shortcode_skill':
                var c = cm.createSplitButton('shortcode_skill', {
                    title : 'Counters',
                    onclick : function() {
                    }
                });

                c.onRenderMenu.add(function(c, m) {
                    m.onShowMenu.add(function(c,m){
                        jQuery('#menu_'+c.id).height('auto').width('auto');
                        jQuery('#menu_'+c.id+'_co').height('auto').addClass('mceListBoxMenu'); 
                        var $menu = jQuery('#menu_'+c.id+'_co').find('tbody:first');
                        if($menu.data('added')) return;
                        $menu.append('');
                        $menu.append('<div style="padding:0 10px 10px">\
						<label>Skill type <br />\
						<select name="type">\
							<option value="counter_circle">Counter circle</option>\
							<option value="progress_bar">Progress bar</option>\
							<option value="content_box">Content box</option>\
						</select></label>\
						<label>Values (%)<br />\
						<input type="text" name="values" value="" /></label>\
						<label>Speed<br />\
						<i style="font-size:10px;">Ex: 1000</i><br/>\
						<input type="text" name="speed" value="" /></label>\
						<label>Start animation<br />\
						<select name="start_animation">\
							<option value="appearance">At appearance</option>\
							<option value="scroll">When User scroll to</option>\
						</select></label>\
						<div class="form-item"><label for="color1">Progress Color</label><input type="text" name="color_skill" id="color_skill" value="#" /></div><div  id="picker_skill"></div>\
						<div class="form-item"><label for="color1">Background Color</label><input type="text" name="color_skill1" id="color_skill1" value="#" /></div><div  id="picker_skill1"></div>\
						<div class="form-item"><label for="color1">Text Color</label><input type="text" name="color_skill2" id="color_skill2" value="#" /></div><div  id="picker_skill2"></div>\
						<label>Animation:<br />\
						<select name="animation">\
							<option value="">No</option>\
							<option value="top-to-bottom">Top to bottom</option>\
							<option value="bottom-to-top">Bottom to top</option>\
							<option value="left-to-right">Left to right</option>\
							<option value="right-to-left">Right to left</option>\
							<option value="appear">Appear</option>\
						</select></label>\
                        </div>');
						  jQuery(document).ready(function() {
							jQuery('#color_skill').click(function(){
								jQuery('#menu_content_content_shortcode_skill_menu_tbl').css("width","207px");
								jQuery('#picker_skill').farbtastic('#color_skill').show();
								jQuery('#picker_skill1').farbtastic('#color_skill1').hide();
								jQuery('#picker_skill2').farbtastic('#color_skill2').hide();
							});
							jQuery('#color_skill1').click(function(){
								jQuery('#menu_content_content_shortcode_skill_menu_tbl').css("width","207px");
								jQuery('#picker_skill1').farbtastic('#color_skill1').show();
								jQuery('#picker_skill').farbtastic('#color_skill').hide();
								jQuery('#picker_skill2').farbtastic('#color_skill2').hide();
							});
							jQuery('#color_skill2').click(function(){
								jQuery('#menu_content_content_shortcode_skill_menu_tbl').css("width","207px");
								jQuery('#picker_skill2').farbtastic('#color_skill2').show();
								jQuery('#picker_skill1').farbtastic('#color_skill1').hide();
								jQuery('#picker_skill').farbtastic('#color_skill').hide();
							});
							jQuery('#color_skill, #color_skill1, #color_skill2').focusout(function(){
								jQuery('#menu_content_content_shortcode_skill_menu_tbl').css("width","auto");
								jQuery('#picker_skill').farbtastic('#color_skill').hide();
								jQuery('#picker_skill1').farbtastic('#color_skill1').hide();
								jQuery('#picker_skill2').farbtastic('#color_skill2').hide();
							});
						  });

							jQuery('<input type="button" class="button" value="Insert" />').appendTo($menu)
                                .click(function(){
                       
                                var uID =  Math.floor((Math.random()*100)+1);
								var type = $menu.find('select[name=type]').val();
                               	var values = $menu.find('input[name=values]').val();
								var speed = $menu.find('input[name=speed]').val();
								var start_animation = $menu.find('select[name=start_animation]').val();
								var color_skill = ($menu.find('input[id=color_skill]').val()) ? 'color="'+$menu.find('input[id=color_skill]').val()+'"' : '';
								var color_skill1 = ($menu.find('input[id=color_skill1]').val()) ? 'bg_color="'+$menu.find('input[id=color_skill1]').val()+'"' : '';
								var color_skill2 = ($menu.find('input[id=color_skill2]').val()) ? 'text_color="'+$menu.find('input[id=color_skill2]').val()+'"' : '';
								
								var animation = $menu.find('select[name=animation]').val();
								var  shortcode= '[skill   type="'+type+'" values="'+values+'" speed="'+speed+'" start_animation="'+start_animation+'" '+color_skill+' '+color_skill1+' '+color_skill2+' animation="'+ animation +'"]<br class="nc"/>Content here<br class="nc"/>[/skill]';
                                    tinymce.activeEditor.execCommand('mceInsertContent',false,shortcode);
                                    c.hideMenu();
                                }).wrap('<tr><td><div style="padding: 0 10px 10px"></div></td></tr>')
                 
                        $menu.data('added',true); 

                    });
                   // XSmall
					m.add({title : 'Counters', 'class' : 'mceMenuItemTitle'}).setDisabled(1);

                 });
                // Return the new splitbutton instance
                return c;
                
            }
            return null;
        }
    });
    tinymce.PluginManager.add('shortcode_skill', tinymce.plugins.shortcode_skill);
})();
