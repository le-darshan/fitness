// JavaScript Document
(function() {
    // Creates a new plugin class and a custom listbox
    tinymce.create('tinymce.plugins.ct_shortcode_timeline_event', {
        createControl: function(n, cm) {
            switch (n) {                
                case 'ct_shortcode_timeline_event':
                var c = cm.createSplitButton('ct_shortcode_timeline_event', {
                    title : 'Timeline event list',
                    onclick : function() {
                    }
                });

                c.onRenderMenu.add(function(c, m) {
                    m.onShowMenu.add(function(c,m){
                        jQuery('#menu_'+c.id).height('auto').width('auto');
                        jQuery('#menu_'+c.id+'_co').height('auto').addClass('mceListBoxMenu'); 
                        var $menu = jQuery('#menu_'+c.id+'_co').find('tbody:first');
                        if($menu.data('added')) return;
                        $menu.append('');
                        $menu.append('<div style="padding:0 10px 10px">\
						<label>Ids<br />\
						<i style="font-size:10px;">EX: 1, 2, 3</i><br/>\
						<input type="text" name="ids" value="" /></label>\
                       	<label>Show Events this month only:<br />\
						<select name="emonth">\
							<option value=""></option>\
							<option value="1">1</option>\
							<option value="2">2</option>\
							<option value="3">3</option>\
							<option value="4">4</option>\
							<option value="5">5</option>\
							<option value="6">6</option>\
							<option value="7">7</option>\
							<option value="8">8</option>\
							<option value="9">9</option>\
							<option value="10">10</option>\
							<option value="11">11</option>\
							<option value="12">12</option>\
						</select></label>\
                       	<label>Select Year:<br />\
						<select name="year">\
							<option value="2005">2005</option>\
							<option value="2006">2006</option>\
							<option value="2007">2007</option>\
							<option value="2008">2008</option>\
							<option value="2009">2009</option>\
							<option value="2010">2010</option>\
							<option value="2011">2011</option>\
							<option value="2012">2012</option>\
							<option value="2013">2013</option>\
							<option value="2014">2014</option>\
							<option value="2015">2015</option>\
							<option value="2016">2016</option>\
							<option value="2017">2017</option>\
							<option value="2018">2018</option>\
							<option value="2019">2019</option>\
							<option value="2020">2020</option>\
							<option value="2021">2021</option>\
							<option value="2022">2022</option>\
							<option value="2023">2023</option>\
							<option value="2024">2024</option>\
							<option value="2025">2025</option>\
						</select></label>\
						<label>Show past Event:<br />\
						<select name="show_past">\
							<option value="">No</option>\
							<option value="yes">Yes</option>\
						</select></label>\
						<label>Animation:<br />\
						<select name="animation">\
							<option value="">No</option>\
							<option value="top-to-bottom">Top to bottom</option>\
							<option value="bottom-to-top">Bottom to top</option>\
							<option value="left-to-right">Left to right</option>\
							<option value="right-to-left">Right to left</option>\
							<option value="appear">Appear</option>\
						</select></label>\
                        </div>');
							jQuery('<input type="button" class="button" value="Insert" />').appendTo($menu)
                                .click(function(){
                       
                                var uID =  Math.floor((Math.random()*100)+1);
                                var ids = $menu.find('input[name=ids]').val();
								var emonth = $menu.find('select[name=emonth]').val();
								var year = $menu.find('select[name=year]').val();
								var show_past = $menu.find('select[name=show_past]').val();
								var animation = $menu.find('select[name=animation]').val();
								var  shortcode= '[timeline_event  ids="'+ids+'" emonth="'+emonth+'" year="'+year+'" eventold="'+show_past+'" animation="'+ animation +'"]';
                                    tinymce.activeEditor.execCommand('mceInsertContent',false,shortcode);
                                    c.hideMenu();
                                }).wrap('<tr><td><div style="padding: 0 10px 10px"></div></td></tr>')
                 
                        $menu.data('added',true); 

                    });
                   // XSmall
					m.add({title : 'Timeline event list', 'class' : 'mceMenuItemTitle'}).setDisabled(1);

                 });
                // Return the new splitbutton instance
                return c;
                
            }
            return null;
        }
    });
    tinymce.PluginManager.add('ct_shortcode_timeline_event', tinymce.plugins.ct_shortcode_timeline_event);
})();
