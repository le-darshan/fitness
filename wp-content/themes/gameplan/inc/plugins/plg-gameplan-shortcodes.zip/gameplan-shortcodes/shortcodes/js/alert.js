// JavaScript Document
(function() {
    // Creates a new plugin class and a custom listbox
    tinymce.create('tinymce.plugins.shortcode_alert', {
        createControl: function(n, cm) {
            switch (n) {                
                case 'shortcode_alert':
                var c = cm.createSplitButton('shortcode_alert', {
                    title : 'Alert',
                    onclick : function() {
                    }
                });

                c.onRenderMenu.add(function(c, m) {
                    m.onShowMenu.add(function(c,m){
                        jQuery('#menu_'+c.id).height('auto').width('auto');
                        jQuery('#menu_'+c.id+'_co').height('auto').addClass('mceListBoxMenu'); 
                        var $menu = jQuery('#menu_'+c.id+'_co').find('tbody:first');
                        if($menu.data('added')) return;
                        $menu.append('');
                        $menu.append('<div style="padding:0 10px 10px">\
						<label>Message<br />\
                        <input type="text" name="message" value="" /></label>\
						<label>Links<br />\
                        <input type="text" name="links" value="" /></label>\
 						<label>Icon in font <a style="display:inline;text-decoration:underline !important;cursor:pointer;" href="http://fortawesome.github.io/Font-Awesome/icons/">Awesome</a><br />\
						<i style="font-size:10px;">Name EX: icon-mobile-phone</i><br/>\
                        <input type="text" name="icon" value="" /></label>\
                       <label>Style<br />\
						<select name="style">\
							<option value=""></option>\
							<option value="border_style">Border style</option>\
						</select></label>\
						<div class="form-item"><label for="color_a1">Color</label><input type="text" id="color_a1" name="color_a1" value="#e0e0e0" /></div><div id="picker_a1"></div>\
						<div class="form-item"><label for="color_a2">Border Color</label><input type="text" id="color_a2" name="color_a2" value="#e0e0e0" /></div><div id="picker_a2"></div>\
						<div class="form-item"><label for="color_a3">Background Color </label><input type="text" id="color_a3" name="color_a3" value="#E9E9E9" /></div><div id="picker_a3"></div>\
						<label>Animation:<br />\
						<select name="animation">\
							<option value="">No</option>\
							<option value="top-to-bottom">Top to bottom</option>\
							<option value="bottom-to-top">Bottom to top</option>\
							<option value="left-to-right">Left to right</option>\
							<option value="right-to-left">Right to left</option>\
							<option value="appear">Appear</option>\
						</select></label>\
                        </div>');
						  jQuery(document).ready(function() {
							jQuery('#color_a1').click(function(){
								jQuery('#menu_content_content_shortcode_alert_menu_tbl').css("width","207px");
								jQuery('#picker_a1').farbtastic('#color_a1').show();
								jQuery('#picker_a2').farbtastic('#color_a2').hide();
								jQuery('#picker_a3').farbtastic('#color_a3').hide();
							});
							jQuery('#color_a2').click(function(){
								jQuery('#menu_content_content_shortcode_alert_menu_tbl').css("width","207px");
								jQuery('#picker_a1').farbtastic('#color_a1').hide();
								jQuery('#picker_a2').farbtastic('#color_a2').show();
								jQuery('#picker_a3').farbtastic('#color_a3').hide();
							});
							jQuery('#color_a3').click(function(){
								jQuery('#menu_content_content_shortcode_alert_menu_tbl').css("width","207px");
								jQuery('#picker_a1').farbtastic('#color_a1').hide();
								jQuery('#picker_a2').farbtastic('#color_a2').hide();
								jQuery('#picker_a3').farbtastic('#color_a3').show();
							});
						  });
							jQuery('<input type="button" class="button" value="Insert" />').appendTo($menu)
                                .click(function(){
                       
                                var uID =  Math.floor((Math.random()*100)+1);
                                var message = $menu.find('input[name=message]').val();
								var links = $menu.find('input[name=links]').val();
								var style = $menu.find('select[name=style]').val();
								var animation = $menu.find('select[name=animation]').val();
								var icon = ($menu.find('input[name=icon]').val()) ? 'icon="'+$menu.find('input[name=icon]').val()+'"' : '';
								var color_a1 = ($menu.find('input[id=color_a1]').val()) ? 'color="'+$menu.find('input[id=color_a1]').val()+'"' : '';
								var color_a2 = ($menu.find('input[name=color_a2]').val()) ? 'bd_color="'+$menu.find('input[name=color_a2]').val()+'"' : '';
								var color_a3 = ($menu.find('input[id=color_a3]').val()) ? 'background="'+$menu.find('input[id=color_a3]').val()+'"' : '';			
								var shortcode = '[alert  id="alert_'+uID+'" message="'+message+'" link="'+links+'" style="'+style+'" '+icon+' '+color_a1+' '+color_a2+' '+color_a3+' animation="'+animation+'"]<br class="nc"/>';

                                    tinymce.activeEditor.execCommand('mceInsertContent',false,shortcode);
                                    c.hideMenu();
                                }).wrap('<tr><td><div style="padding: 0 10px 10px"></div></td></tr>')
                 
                        $menu.data('added',true); 

                    });

                   // XSmall
					m.add({title : 'Alert', 'class' : 'mceMenuItemTitle'}).setDisabled(1);

                 });
                // Return the new splitbutton instance
                return c;
                
            }
            return null;
        }
    });
    tinymce.PluginManager.add('shortcode_alert', tinymce.plugins.shortcode_alert);
})();
