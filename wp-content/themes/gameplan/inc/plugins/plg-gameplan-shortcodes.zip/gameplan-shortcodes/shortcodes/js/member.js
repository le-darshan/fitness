// JavaScript Document
(function() {
    // Creates a new plugin class and a custom listbox
    tinymce.create('tinymce.plugins.shortcode_member', {
        createControl: function(n, cm) {
            switch (n) {                
                case 'shortcode_member':
                var c = cm.createSplitButton('shortcode_member', {
                    title : 'Member',
                    onclick : function() {
                    }
                });

                c.onRenderMenu.add(function(c, m) {
                    m.onShowMenu.add(function(c,m){
                        jQuery('#menu_'+c.id).height('auto').width('auto');
                        jQuery('#menu_'+c.id+'_co').height('auto').addClass('mceListBoxMenu'); 
                        var $menu = jQuery('#menu_'+c.id+'_co').find('tbody:first');
                        if($menu.data('added')) return;
                        $menu.append('');
                        $menu.append('<div style="padding:0 10px 10px">\
						<label>ID Member<br />\
						<input type="text" name="id" value="" /></label>\
						<div class="form-item"><label for="color1">Background Color</label><input type="text" id="color-member" name="color-member" value="#" /></div><div id="picker-member"></div>\
						<label>Animation:<br />\
						<select name="animation">\
							<option value="">No</option>\
							<option value="top-to-bottom">Top to bottom</option>\
							<option value="bottom-to-top">Bottom to top</option>\
							<option value="left-to-right">Left to right</option>\
							<option value="right-to-left">Right to left</option>\
							<option value="appear">Appear</option>\
						</select></label>\
                        </div>');
						  jQuery(document).ready(function() {
							jQuery('#color-member').click(function(){
								jQuery('#menu_content_content_shortcode_member_menu_tbl').css("width","207px");
								jQuery('#picker-member').farbtastic('#color-member').show();
							});
						  });

							jQuery('<input type="button" class="button" value="Insert" />').appendTo($menu)
                                .click(function(){
                       
                                var uID =  Math.floor((Math.random()*100)+1);
                                var id = $menu.find('input[name=id]').val();
								var bg_color = ($menu.find('input[id=color-member]').val()) ? 'bg_color="'+$menu.find('input[id=color-member]').val()+'"' : '';
								var animation = $menu.find('select[name=animation]').val();
								var  shortcode= '[member  id="'+id+'" '+bg_color+' animation="'+ animation +'"]';
                                    tinymce.activeEditor.execCommand('mceInsertContent',false,shortcode);
                                    c.hideMenu();
                                }).wrap('<tr><td><div style="padding: 0 10px 10px"></div></td></tr>')
                 
                        $menu.data('added',true); 

                    });
                   // XSmall
					m.add({title : 'Member', 'class' : 'mceMenuItemTitle'}).setDisabled(1);

                 });
                // Return the new splitbutton instance
                return c;
                
            }
            return null;
        }
    });
    tinymce.PluginManager.add('shortcode_member', tinymce.plugins.shortcode_member);
})();
