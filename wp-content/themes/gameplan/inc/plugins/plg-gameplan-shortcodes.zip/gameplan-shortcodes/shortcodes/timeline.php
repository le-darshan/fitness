<?php
/**
 * WPBakery Visual Composer shortcodes
 *
 * @package WPBakeryVisualComposer
 *
 */

class WPBakeryShortCode_Timeline_item extends WPBakeryShortCode_VC_Tab {
    protected  $predefined_atts = array(
					'title' => 'Timeline Item',
					'text' => ''
						);
	
    public function content( $atts, $content = null ) {
        $title = '';
		$text = '';
		$id = rand();
        extract(shortcode_atts($this->predefined_atts, $atts));
		global $demsl;
		$demsl++;
        $output = '';

        $output .= "\n\t\t\t" . '<div class="timeline" id="tl'.$id.'">';
        $output .= "\n\t\t\t\t" . '<div class="row-fluid">';
		$output .= "\n\t\t\t\t" . '<div class="col1">';
		$output .= "\n\t\t\t\t" . '</div>';
		$output .= "\n\t\t\t\t" . '<div class="col11">';
		$output .= "\n\t\t\t\t" . '<span class="dot"><span></span></span>';
		$output .= "\n\t\t\t\t" . '<span class="line"></span>';
		$output .= "\n\t\t\t\t" . '<span class="title" >'.$title.'</span>';
        $output .= "\n\t\t\t\t" . '<span class="content">'.$text.'</span>';
        $output .= "\n\t\t\t\t" . '</div>';
		$output .= "\n\t\t\t\t" . '</div>';
        $output .= "\n\t\t\t" . '</div> ';
        return $output;
    }

    public function contentAdmin($atts, $content = null) {
        $width = $el_class = $title = '';
        extract(shortcode_atts($this->predefined_atts, $atts));
		
        $output = '';

        $column_controls = $this->getColumnControls($this->settings('controls'));
        $column_controls_bottom =  $this->getColumnControls('add', 'bottom-controls');
        
		$output .= '<div class="group wpb_sortable">';
			$output .= '<h3><span class="tab-label"><%= params.title %></span></h3>';
			$output .= '<div '.$this->mainHtmlBlockParams($width, 0).'>';
				$output .= str_replace("%column_size%", wpb_translateColumnWidthToFractional($width[0]), $column_controls);
				$output .= '<div class="wpb_element_wrapper">';
					$output .= '<div '.$this->containerHtmlBlockParams($width, 0).'>';
						$output .= '<%= params.text %>';
						$output .= do_shortcode( shortcode_unautop($content) );
						$output .= WPBakeryVisualComposer::getInstance()->getLayout()->getContainerHelper();
					$output .= '</div>';
					
					if ( isset($this->settings['params']) ) {
						$inner = '';
						foreach ($this->settings['params'] as $param) {
							$param_value = isset($$param['param_name']) ? $$param['param_name'] : '';
							if ( is_array($param_value)) {
								// Get first element from the array
								reset($param_value);
								$first_key = key($param_value);
								$param_value = $param_value[$first_key];
							}
							$inner .= $this->singleParamHtmlHolder($param, $param_value);
						}
						$output .= $inner;
					}
				$output .= '</div>';
				$output .= str_replace("%column_size%", wpb_translateColumnWidthToFractional($width[$i]), $column_controls_bottom);
			$output .= '</div>';
		$output .= '</div>';
			
        return $output;
    }
	
	public function mainHtmlBlockParams($width, $i) {
        return 'data-element_type="'.$this->settings["base"].'" class="' . $this->settings['class'] . ' wpb_'.$this->settings['base'].'"'.$this->customAdminBlockParams();
    }
    public function containerHtmlBlockParams($width, $i) {
        return 'class="wpb_column_container"';
    }
	
	public function contentAdmin_old($atts, $content = null) {
        $width = $el_class = $title = '';
        extract(shortcode_atts($this->predefined_atts, $atts));
        $output = '';
        $column_controls = $this->getColumnControls($this->settings('controls'));
        for ( $i=0; $i < count($width); $i++ ) {
            $output .= '<div class="group wpb_sortable">';
            $output .= '<div class="wpb_element_wrapper">';
            $output .= '<div class="vc_row-fluid wpb_row_container">';
            $output .= '<h3><a href="#">'.$title.'</a></h3>';
            $output .= '<div '.$this->customAdminBockParams().' data-element_type="'.$this->settings["base"].'" class=" wpb_'.$this->settings['base'].' wpb_sortable">';
            $output .= '<div class="wpb_element_wrapper">';
            $output .= '<div class="vc_row-fluid wpb_row_container">';
            $output .= do_shortcode( shortcode_unautop($content) );
            $output .= '</div>';
            if ( isset($this->settings['params']) ) {
                $inner = '';
                foreach ($this->settings['params'] as $param) {
                    $param_value = isset($$param['param_name']) ? $$param['param_name'] : '';
                    if ( is_array($param_value)) {
                        // Get first element from the array
                        reset($param_value);
                        $first_key = key($param_value);
                        $param_value = $param_value[$first_key];
                    }
                    $inner .= $this->singleParamHtmlHolder($param, $param_value);
                }
                $output .= $inner;
            }
            $output .= '</div>';
            $output .= '</div>';
            $output .= '</div>';
            $output .= '</div>';
            $output .= '</div>';
        }

        return $output;
    }

    protected function outputTitle($title) {
        return  '';
    }

    public function customAdminBlockParams() {
        return '';
    }

}
vc_map( array(
    "name"		=> __("Timeline item", "cactusthemes"),
    "base"		=> "timeline_item", 
    "class"		=> "wpb_vc_accordion_tab",
    "icon"      => "",
    "wrapper_class" => "",
    "controls"	=> "full",
    "content_element" => false,
    "params"	=> array(
        array(
            "type" => "textfield",
            "heading" => __("Title", "cactusthemes"),
            "param_name" => "title",
            "value" => "",
            "description" => '',
        ),
        array(
            "type" => "textarea",
            "heading" => __("Content", "cactusthemes"),
            "param_name" => "text",
            "value" => "",
            "description" => '',
        ),

    ),
	'js_view'=>'VcTimelineItemView'
) );

class WPBakeryShortCode_timeline extends WPBakeryShortCode {

    public function __construct($settings) {
        parent::__construct($settings);
        // WPBakeryVisualComposer::getInstance()->addShortCode( array( 'base' => 'vc_accordion_tab' ) );
    }

    protected function content( $atts, $content = null ) {
        wp_enqueue_style( 'ui-custom-theme' );
        wp_enqueue_script('jquery-ui-accordion');
        $title = $interval = $width = $el_position = $el_class = $animation_class = '';
        //
        extract(shortcode_atts(array(
            'title' => '',
            'interval' => 0,
            'width' => '1/1',
            'el_position' => '',
            'el_class' => '',
			'animation'=>''
        ), $atts));
        $output = '';
		global $demsl;
		$demsl=0;
        $el_class = $this->getExtraClass($el_class);
		if(class_exists('Mobile_Detect')){
			$detect = new Mobile_Detect;
			$_device_ = $detect->isMobile() ? ($detect->isTablet() ? 'tablet' : 'mobile') : 'pc';
			if(isset($atts['animation'])){
			$animation_class = ($atts['animation']&&$_device_=='pc')?'wpb_'.$atts['animation'].' wpb_animate_when_almost_visible':'';
			}
		}else{
			if(isset($atts['animation'])){
			$animation_class = $atts['animation']?'wpb_'.$atts['animation'].' wpb_animate_when_almost_visible':'';
			}
		}
        $width = '';//wpb_translateColumnWidthToSpan($width);

        $output .= "\n\t".'<div class="wpb_accordion wpb_content_element '.$width.$el_class.' '.$animation_class.' not-column-inherit">'; //data-interval="'.$interval.'"
        $output .= "\n\t\t".'<div class="wpb_wrapper wpb_accordion_wrapper ui-accordion boxed timeline-list">';
        //$output .= ($title != '' ) ? "\n\t\t\t".'<h2 class="wpb_heading wpb_accordion_heading">'.$title.'</h2>' : '';
        $output .= wpb_widget_title(array('title' => $title, 'extraclass' => 'wpb_accordion_heading'));

        $output .= "\n\t\t\t".wpb_js_remove_wpautop($content);
        $output .= "\n\t\t".'</div> '.$this->endBlockComment('.wpb_wrapper');
        $output .= "\n\t".'</div> '.$this->endBlockComment($width);
		if($demsl==1)
		{
			$output .= "\n\t".'
			<style type="text/css" scoped="scoped">
			.timeline .row-fluid .col11 .line{ position:absolute;top:-17px; left:-34px; font-size:18px; border-left:0 ;}
			</style> 
			';
		}

		
        //
        $output = $this->startRow($el_position) . $output . $this->endRow($el_position);
        return $output;

    }

    public function contentAdmin( $atts, $content ) {	
        $width = $custom_markup = '';
        $shortcode_attributes = array('width' => '1/1');
        foreach ( $this->settings['params'] as $param ) {
            if ( $param['param_name'] != 'content' ) {
                if (isset($param['value']) && is_string($param['value']) ) {
                    $shortcode_attributes[$param['param_name']] = __($param['value'], "js_composer");
                } elseif(isset($param['value'])){
                    $shortcode_attributes[$param['param_name']] = $param['value'];
                }
            } else if ( $param['param_name'] == 'content' && $content == NULL ) {
                $content = __($param['value'], "js_composer");
            }
        }
        extract(shortcode_atts(
            $shortcode_attributes
            , $atts));

        $output = '';

        $elem = $this->getElementHolder($width);

        $inner = '';
        foreach ($this->settings['params'] as $param) {
            $param_value = '';
            $param_value = isset($$param['param_name']) ? $$param['param_name'] : '';
            if ( is_array($param_value)) {
                // Get first element from the array
                reset($param_value);
                $first_key = key($param_value);
                $param_value = $param_value[$first_key];
            }
            $inner .= $this->singleParamHtmlHolder($param, $param_value);
        }
        //$elem = str_ireplace('%wpb_element_content%', $inner, $elem);
        $tmp = '';
        //$template = '<div class="wpb_template">'.do_shortcode('[timeline_item title="New timeline item"][/timeline_item]').'</div>';

        if ( isset($this->settings["custom_markup"]) && $this->settings["custom_markup"] != '' ) {
			
            if ( $content != '' ) {
                $custom_markup = str_ireplace("%content%", $tmp.$content, $this->settings["custom_markup"]);
            } else if ( $content == '' && isset($this->settings["default_content_in_template"]) && $this->settings["default_content_in_template"] != '' ) {
                $custom_markup = str_ireplace("%content%", $this->settings["default_content_in_template"], $this->settings["custom_markup"]);
            } else {
                $custom_markup =  str_ireplace("%content%", '', $this->settings["custom_markup"]);
            }
            //$output .= do_shortcode($this->settings["custom_markup"]);
            $inner .= do_shortcode($custom_markup);
        }
        $elem = str_ireplace('%wpb_element_content%', $inner, $elem);
        $output = $elem;

        return $output;
    }
}
vc_map( array(
    "name"		=> __("Timeline", "js_composer"),
    "base"		=> "timeline",
    "controls"	=> "full",
    "show_settings_on_create" => false,
	"is_container" => true,
    "class"		=> "wpb_vc_accordion vc_not_inner_content wpb_container_block",
	//"icon"		=> "icon-wpb-ui-timeline",
	"category"  => __('Content', "cactusthemes"),
//	"wrapper_class" => "clearfix",
    "params"	=> array(
		array(		
		 "type" => "dropdown",
		 "holder" => "div",
		 "class" => "",
		 "heading" => __("CSS Animation", 'cactusthemes'),
		 "param_name" => "animation",
		 "value" => array(
			__("No", 'cactusthemes') => '',
			__("Top to bottom", 'cactusthemes') => 'top-to-bottom',
			__("Bottom to top", 'cactusthemes') => 'bottom-to-top',
			__("Left to right", 'cactusthemes') => 'left-to-right',
			__("Right to left", 'cactusthemes') => 'right-to-left',
			__("Appear from center", 'cactusthemes') => 'appear',
		 ),
		 "description" => ''
	  ),
    ),
    "custom_markup" => '
<div class="wpb_accordion_holder wpb_holder clearfix vc_container_for_children">
  %content%
  </div>
  <div class="tab_controls">
  <button class="add_tab" title="'.__("Add timeline item", "cactusthemes").'">'.__("Add timeline item", "cactusthemes").'</button>
  </div>',
    'default_content' => '
     [timeline_item title="Timeline Item 1"][/timeline_item]
     [timeline_item title="Timeline Item 2"][/timeline_item]
    ',
	'js_view' => 'VcTimelineView'
) );



