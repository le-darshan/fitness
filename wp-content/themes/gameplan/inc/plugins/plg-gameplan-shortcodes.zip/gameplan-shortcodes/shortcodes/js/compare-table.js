// JavaScript Document
function mycolor(){
	alert ("<input class='color'>");
}
(function() {
    // Creates a new plugin class and a custom listbox
    tinymce.create('tinymce.plugins.ct_shortcode_compare_table', {
        createControl: function(n, cm) {
            switch (n) {                
                case 'ct_shortcode_compare_table':
                var c = cm.createSplitButton('ct_shortcode_compare_table', {
                    title : 'Compare Table',
                    onclick : function() {
                    }
                });

                c.onRenderMenu.add(function(c, m) {
                    m.onShowMenu.add(function(c,m){
                        jQuery('#menu_'+c.id).height('auto').width('auto');
                        jQuery('#menu_'+c.id+'_co').height('auto').addClass('mceListBoxMenu'); 
                        var $menu = jQuery('#menu_'+c.id+'_co').find('tbody:first');
                        if($menu.data('added')) return;
                        $menu.append('');
                        $menu.append('<div style="padding:0 10px 10px">\
                        <label>Number of column<br />\
                        <input type="text" name="column" value="3" onclick="this.select()"  /></label>\
						<label>Number of row<br />\
                        <input type="text" name="row" value="5" onclick="this.select()"  /></label>\
						<label>Style<br/>\
						<select name="style" value="tb-style-1">\
						<option value="tb-style-1">Style 1</option>\
						<option value="tb-style-2">Style 2</option>\
						</select></label>\
						<div class="form-item"><label for="color1">Background Color highlight</label><input type="text" id="color-compa1" name="color-compa1" value="#" /></div><div id="picker-compa1"></div>\
						<div class="form-item"><label for="color2">Background Color </label><input type="text" id="color-compa2" name="color-compa2" value="#" /></div><div id="picker-compa2"></div>\
                        </div>');
						  jQuery(document).ready(function() {
							jQuery('#picker').hide();
							jQuery('#color-compa1').click(function(){
								jQuery('#menu_content_content_ct_shortcode_compare_table_menu_tbl').css("width","207px");
								jQuery('#picker-compa1').farbtastic('#color-compa1').show();
								jQuery('#picker-compa2').farbtastic('#color-compa2').hide();
							});
							jQuery('#color-compa1').focusout(function(){
								jQuery('#menu_content_content_ct_shortcode_compare_table_menu_tbl').css("width","auto");
								jQuery('#picker-compa1').farbtastic('#color-compa1').hide();
							});
							jQuery('#color-compa2').click(function(){
								jQuery('#menu_content_content_ct_shortcode_compare_table_menu_tbl').css("width","207px");
								jQuery('#picker-compa2').farbtastic('#color-compa2').show();
								jQuery('#picker-compa1').farbtastic('#color-compa1').hide();
							});

						  });

                        jQuery('<input type="button" class="button" value="Insert" />').appendTo($menu)
						.click(function(){

                                var uID =  Math.floor((Math.random()*100)+1);
                                var column = $menu.find('input[name=column]').val();
								var row = $menu.find('input[name=row]').val();
								var style = $menu.find('select[name=style]').val();
								var color = $menu.find('input[name=color-compa1]').val();
								var bg_color = $menu.find('input[name=color-compa2]').val();
								var bg_color = ($menu.find('input[id=color-compa2]').val()) ? 'bg_color="'+$menu.find('input[id=color-compa2]').val()+'"' : '';
								var shortcode = '[comparetable id="comparetable_'+uID+'" class="'+style+'"]<br class="nc"/>';
								for(i=0;i<column;i++){
									if(style != 'compare-table-2'){
										if(i == 0)
											shortcode+= '[c-column class="tb-left" column="'+column+'" '+bg_color+']<br class="nc"/>';
										else if(i == 1)
											shortcode+= '[c-column class="tb-center" column="'+column+'" '+bg_color+']<br class="nc"/>';
										else
											shortcode+= '[c-column  class="tb-right" column="'+column+'" '+bg_color+']<br class="nc"/>';	
									}else{
										if(i == 0)
											shortcode+= '[c-column class="compare-table-feature" column="'+column+'" '+bg_color+']<br class="nc"/>';
										else if(i == 1)
											shortcode+= '[c-column class="tb-left" column="'+column+'" '+bg_color+']<br class="nc"/>';
										else if(i == 2)
											if(column<4)
												shortcode+= '[c-column class="tb-center compare-table-column-2" column="'+column+'" '+bg_color+']<br class="nc"/>';
											else
												shortcode+= '[c-column class="tb-center" column="'+column+'" '+bg_color+']<br class="nc"/>';
										else if(i == 3)
											shortcode+= '[c-column class="compare-table-copper" column="'+column+'" '+bg_color+']<br class="nc"/>';
										else
											shortcode+= '[c-column column="'+column+'" '+bg_color+']<br class="nc"/>';	
									}
									for(j=0; j<row; j++){
										if(style != 'compare-table-2'){
											if(j==0){
												shortcode+= '[c-row class="row-first" ]Content here….[/c-row]<br class="nc"/>';
												shortcode+= '[c-row]Content here….[/c-row]<br class="nc"/>';
											}
											else if(j==1){
												var colorshortcode = '';
												if(color != 'undefined' && color != null)
													colorshortcode = 'color="' + color + '"';
												shortcode+= '[c-row class="hight-light" '+ colorshortcode +']Content here….[/c-row]<br class="nc"/>';	
											}else
												shortcode+= '[c-row]Content here….[/c-row]<br class="nc"/>';
										}else{
											if(j==0 && i!=0)
												shortcode+= '[c-row class="row-first"][/c-row]<br class="nc"/>';
											else if(j==1)
												if(i==0)
													shortcode+= '[c-row class="hight-light" ][/c-row]<br class="nc"/>';
												else{
													var colorshortcode = '';
													if(color != 'undefined' && color != null)
														colorshortcode = 'color="' + color + '"';		
													shortcode+= '[c-row class="hight-light" '+colorshortcode+']Content here….[/c-row]<br class="nc"/>';	
												}
											else if(j!=0)
												shortcode+= '[c-row]Content here….[/c-row]<br class="nc"/>';
										}
									}
									shortcode += '[/c-column]<br class="nc"/>';
								}
                                shortcode+= '[/comparetable]<br class="nc"/>';

                                    tinymce.activeEditor.execCommand('mceInsertContent',false,shortcode);
                                    c.hideMenu();
                                }).wrap('<div style="padding: 0 10px 10px"></div>')
                 
                        $menu.data('added',true); 

                    });

                   // XSmall
					m.add({title : 'Compare table', 'class' : 'mceMenuItemTitle'}).setDisabled(1);

                 });
                // Return the new splitbutton instance
                return c;
                
            }
            return null;
        }
    });
    tinymce.PluginManager.add('ct_shortcode_compare_table', tinymce.plugins.ct_shortcode_compare_table);
})();